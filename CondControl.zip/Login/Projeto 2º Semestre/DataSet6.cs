﻿partial class DataSet6
{
    partial class UsuariosDataTable
    {
    }
}
