﻿namespace Cond._Control
{


    partial class DataSet1
    {
    }
}
