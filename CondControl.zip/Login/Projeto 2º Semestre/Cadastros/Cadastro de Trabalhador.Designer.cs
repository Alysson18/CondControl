﻿namespace Cond._Control
{
    partial class Cadastro_de_Trabalhador
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Cadastro_de_Trabalhador));
            this.BtConfirmar = new System.Windows.Forms.Button();
            this.TbNum = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.TbPropietario = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.TbEndereco = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.TbNome = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.cbServico = new System.Windows.Forms.ComboBox();
            this.label10 = new System.Windows.Forms.Label();
            this.dtInicio = new System.Windows.Forms.DateTimePicker();
            this.cbAcesso = new System.Windows.Forms.ComboBox();
            this.label11 = new System.Windows.Forms.Label();
            this.dtFinal = new System.Windows.Forms.DateTimePicker();
            this.label12 = new System.Windows.Forms.Label();
            this.btLiberar = new System.Windows.Forms.Button();
            this.btEncerrar = new System.Windows.Forms.Button();
            this.tbRg = new System.Windows.Forms.MaskedTextBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label6 = new System.Windows.Forms.Label();
            this.TbTelefone = new System.Windows.Forms.MaskedTextBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // BtConfirmar
            // 
            this.BtConfirmar.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.BtConfirmar.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gray;
            this.BtConfirmar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtConfirmar.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtConfirmar.ForeColor = System.Drawing.Color.White;
            this.BtConfirmar.Location = new System.Drawing.Point(490, 367);
            this.BtConfirmar.Name = "BtConfirmar";
            this.BtConfirmar.Size = new System.Drawing.Size(199, 40);
            this.BtConfirmar.TabIndex = 10;
            this.BtConfirmar.Text = "Confirmar";
            this.BtConfirmar.UseVisualStyleBackColor = false;
            this.BtConfirmar.Click += new System.EventHandler(this.BtConfirmar_Click);
            // 
            // TbNum
            // 
            this.TbNum.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.TbNum.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TbNum.Location = new System.Drawing.Point(491, 310);
            this.TbNum.Name = "TbNum";
            this.TbNum.Size = new System.Drawing.Size(200, 31);
            this.TbNum.TabIndex = 8;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.White;
            this.label9.Location = new System.Drawing.Point(486, 282);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(36, 25);
            this.label9.TabIndex = 108;
            this.label9.Text = "Nº";
            // 
            // TbPropietario
            // 
            this.TbPropietario.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.TbPropietario.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TbPropietario.Location = new System.Drawing.Point(44, 376);
            this.TbPropietario.Name = "TbPropietario";
            this.TbPropietario.Size = new System.Drawing.Size(389, 31);
            this.TbPropietario.TabIndex = 9;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.White;
            this.label8.Location = new System.Drawing.Point(39, 348);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(128, 25);
            this.label8.TabIndex = 109;
            this.label8.Text = "Proprietário";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.White;
            this.label7.Location = new System.Drawing.Point(486, 140);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(166, 25);
            this.label7.TabIndex = 103;
            this.label7.Text = "Tipo de Serviço";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(39, 140);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(85, 25);
            this.label5.TabIndex = 101;
            this.label5.Text = "Celular";
            // 
            // TbEndereco
            // 
            this.TbEndereco.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.TbEndereco.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TbEndereco.Location = new System.Drawing.Point(44, 310);
            this.TbEndereco.Name = "TbEndereco";
            this.TbEndereco.Size = new System.Drawing.Size(389, 31);
            this.TbEndereco.TabIndex = 7;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(39, 282);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(109, 25);
            this.label4.TabIndex = 107;
            this.label4.Text = "Endereço";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(251, 140);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(42, 25);
            this.label2.TabIndex = 102;
            this.label2.Text = "RG";
            // 
            // TbNome
            // 
            this.TbNome.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.TbNome.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TbNome.Location = new System.Drawing.Point(44, 101);
            this.TbNome.Name = "TbNome";
            this.TbNome.Size = new System.Drawing.Size(646, 31);
            this.TbNome.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(39, 73);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(237, 25);
            this.label1.TabIndex = 100;
            this.label1.Text = "Nome do Trabalhador";
            // 
            // cbServico
            // 
            this.cbServico.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbServico.FormattingEnabled = true;
            this.cbServico.Items.AddRange(new object[] {
            "AJUDANTE",
            "PINTOR",
            "PEDREIRO",
            "PISCINEIRO",
            "MARCINEIRO",
            "MONTADOR",
            "OUTROS"});
            this.cbServico.Location = new System.Drawing.Point(491, 168);
            this.cbServico.Name = "cbServico";
            this.cbServico.Size = new System.Drawing.Size(199, 31);
            this.cbServico.TabIndex = 3;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.White;
            this.label10.Location = new System.Drawing.Point(38, 206);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(160, 25);
            this.label10.TabIndex = 104;
            this.label10.Text = "Inicio da Obra\r\n";
            // 
            // dtInicio
            // 
            this.dtInicio.CalendarFont = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtInicio.CustomFormat = "";
            this.dtInicio.DropDownAlign = System.Windows.Forms.LeftRightAlignment.Right;
            this.dtInicio.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtInicio.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtInicio.Location = new System.Drawing.Point(43, 237);
            this.dtInicio.Name = "dtInicio";
            this.dtInicio.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.dtInicio.Size = new System.Drawing.Size(155, 31);
            this.dtInicio.TabIndex = 4;
            // 
            // cbAcesso
            // 
            this.cbAcesso.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbAcesso.FormattingEnabled = true;
            this.cbAcesso.Items.AddRange(new object[] {
            "LIBERADO",
            "BLOQUEADO"});
            this.cbAcesso.Location = new System.Drawing.Point(490, 237);
            this.cbAcesso.Name = "cbAcesso";
            this.cbAcesso.Size = new System.Drawing.Size(199, 31);
            this.cbAcesso.TabIndex = 6;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.White;
            this.label11.Location = new System.Drawing.Point(486, 206);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(85, 25);
            this.label11.TabIndex = 106;
            this.label11.Text = "Acesso";
            // 
            // dtFinal
            // 
            this.dtFinal.CalendarFont = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtFinal.CustomFormat = "";
            this.dtFinal.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtFinal.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtFinal.Location = new System.Drawing.Point(256, 237);
            this.dtFinal.Name = "dtFinal";
            this.dtFinal.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.dtFinal.Size = new System.Drawing.Size(177, 31);
            this.dtFinal.TabIndex = 5;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.White;
            this.label12.Location = new System.Drawing.Point(251, 206);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(192, 25);
            this.label12.TabIndex = 105;
            this.label12.Text = "Dia Final da Obra\r\n";
            // 
            // btLiberar
            // 
            this.btLiberar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.btLiberar.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.btLiberar.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gray;
            this.btLiberar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btLiberar.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btLiberar.ForeColor = System.Drawing.Color.White;
            this.btLiberar.Location = new System.Drawing.Point(490, 366);
            this.btLiberar.Name = "btLiberar";
            this.btLiberar.Size = new System.Drawing.Size(199, 41);
            this.btLiberar.TabIndex = 10;
            this.btLiberar.Text = "Liberar";
            this.btLiberar.UseVisualStyleBackColor = false;
            this.btLiberar.Click += new System.EventHandler(this.btLiberar_Click);
            // 
            // btEncerrar
            // 
            this.btEncerrar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.btEncerrar.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Red;
            this.btEncerrar.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gray;
            this.btEncerrar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btEncerrar.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btEncerrar.ForeColor = System.Drawing.Color.White;
            this.btEncerrar.Location = new System.Drawing.Point(490, 366);
            this.btEncerrar.Name = "btEncerrar";
            this.btEncerrar.Size = new System.Drawing.Size(199, 40);
            this.btEncerrar.TabIndex = 10;
            this.btEncerrar.Text = "Encerrar";
            this.btEncerrar.UseVisualStyleBackColor = false;
            this.btEncerrar.Click += new System.EventHandler(this.btEncerrar_Click);
            // 
            // tbRg
            // 
            this.tbRg.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbRg.Location = new System.Drawing.Point(256, 168);
            this.tbRg.Mask = "00,000,000-a";
            this.tbRg.Name = "tbRg";
            this.tbRg.Size = new System.Drawing.Size(177, 31);
            this.tbRg.TabIndex = 2;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(686, 2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(47, 33);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 81;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Century Gothic", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.Location = new System.Drawing.Point(203, 2);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(345, 32);
            this.label6.TabIndex = 105;
            this.label6.Text = "Cadastro de Trabalhador";
            // 
            // TbTelefone
            // 
            this.TbTelefone.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TbTelefone.Location = new System.Drawing.Point(43, 168);
            this.TbTelefone.Mask = "(99) 00000-0000";
            this.TbTelefone.Name = "TbTelefone";
            this.TbTelefone.Size = new System.Drawing.Size(155, 31);
            this.TbTelefone.TabIndex = 1;
            // 
            // Cadastro_de_Trabalhador
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.ClientSize = new System.Drawing.Size(735, 431);
            this.Controls.Add(this.TbTelefone);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.tbRg);
            this.Controls.Add(this.btEncerrar);
            this.Controls.Add(this.btLiberar);
            this.Controls.Add(this.dtFinal);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.cbAcesso);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.dtInicio);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.cbServico);
            this.Controls.Add(this.BtConfirmar);
            this.Controls.Add(this.TbNum);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.TbPropietario);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.TbEndereco);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.TbNome);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Cadastro_de_Trabalhador";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Cadastro de Trabalhador";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        public System.Windows.Forms.TextBox TbNum;
        private System.Windows.Forms.Label label9;
        public System.Windows.Forms.TextBox TbPropietario;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label5;
        public System.Windows.Forms.TextBox TbEndereco;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label2;
        public System.Windows.Forms.TextBox TbNome;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        public System.Windows.Forms.Button btLiberar;
        public System.Windows.Forms.Button btEncerrar;
        public System.Windows.Forms.Button BtConfirmar;
        public System.Windows.Forms.ComboBox cbServico;
        public System.Windows.Forms.DateTimePicker dtInicio;
        public System.Windows.Forms.DateTimePicker dtFinal;
        public System.Windows.Forms.ComboBox cbAcesso;
        public System.Windows.Forms.MaskedTextBox tbRg;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label6;
        public System.Windows.Forms.MaskedTextBox TbTelefone;
    }
}