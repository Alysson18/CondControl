﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cond._Control
{
   public static class Visitantes
    {
        public static string nome { get; set; }
        public static string telefone { get; set; }
        public static string rg { get; set; }
        public static string endereco { get; set; }
        public static string apartamento { get; set; }
        public static string propietario { get; set; }
        public static string codigo { get; set; }
        public static string data { get; set; }
        public static string id { get; set; }
            public static string alteracao { get; set; }
      
        


    }
}
