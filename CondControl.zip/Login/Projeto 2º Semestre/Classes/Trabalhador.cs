﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cond._Control.Inicio
{
    public static class Trabalhador
    {
        public static string Nome { get; set; }
        public static string Rg { get; set; }
        public static string Telefone { get; set; }
        public static string Veiculo { get; set; }
        public static string TipoServico { get; set; }
        public static string Endereco { get; set; }
        public static string Bloco { get; set; }
        public static string Casa { get; set; }
        public static string Propietario { get; set; }
        public static string Codigo{ get; set; }
        public static string DataInicio{ get; set; }
        public static string DataFim{ get; set; }
        public static string ID{ get; set; }
        public static string Acesso{ get; set; }
        public static string Evento{ get; set; }
    }
}
