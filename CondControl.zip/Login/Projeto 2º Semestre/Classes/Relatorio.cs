﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cond._Control.Inicio
{
    public class Relatorio
    {
        public string Codigo { get; set; }
        public string Nome { get; set; }
        public string Data { get; set; }
        public string HrInicio { get; set; }
        public string HrSaiRef { get; set; }
        public string HrEntRef { get; set; }
        public string HrFim { get; set; }
    }
}
