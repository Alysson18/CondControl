﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cond._Control.Inicio
{
    public class FuncionarioInterno
    {
        public static string Nome { get; set; }
        public static string ID { get; set; }
        public static string Telefone { get; set; }
        public static string Funcao { get; set; }
        public static string RG { get; set; }
        public static string CPF { get; set; }
        public static string Endereco { get; set; }
        public static string Numero { get; set; }
        public static string Email { get; set; }
    }
}
