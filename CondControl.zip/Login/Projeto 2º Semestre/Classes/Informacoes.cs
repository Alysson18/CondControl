﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projeto_2º_Semestre
{
    public static class Informacoes
    {
        public static string ID { get; set; }
        public static string Cod_Funcionario { get; set; }
        public static string Nome { get; set; }
        public static string Usuario { get; set; }
        public static string Senha { get; set; }
        public static string Tema { get; set; }

    }
}
