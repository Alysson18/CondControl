﻿namespace Cond._Control
{


}

namespace Cond._Control.DataSet2TableAdapters
{


    public partial class PontoTableAdapter
    {
    }
}

namespace Cond._Control
{


    partial class DataSet2
    {
        partial class PontoDataTable
        {
        }
    }
}
